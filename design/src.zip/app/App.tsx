import './design-system.css';

export default function App() {
  return (
    <div className="ds-app">
      {/* Sidebar Navigation */}
      <nav className="ds-sidebar">
        <div className="ds-brand">
          <div className="brand-logo">
            <span className="dna-circle-tag">A</span>
            <span>AISI Design System</span>
          </div>
          <div className="version-badge">v2.4</div>
        </div>
        
        <div className="ds-nav">
          <a href="#tokens" className="ds-nav-item active">
            <span className="nav-number">01</span>
            <span>Design Tokens</span>
          </a>
          <a href="#colors" className="ds-nav-item">
            <span className="nav-number">02</span>
            <span>Colors</span>
          </a>
          <a href="#typography" className="ds-nav-item">
            <span className="nav-number">03</span>
            <span>Typography</span>
          </a>
          <a href="#buttons" className="ds-nav-item">
            <span className="nav-number">04</span>
            <span>Buttons</span>
          </a>
          <a href="#badges" className="ds-nav-item">
            <span className="nav-number">05</span>
            <span>Badges & Tags</span>
          </a>
          <a href="#navigation" className="ds-nav-item">
            <span className="nav-number">06</span>
            <span>Navigation</span>
          </a>
          <a href="#nodes" className="ds-nav-item">
            <span className="nav-number">07</span>
            <span>Node Cards</span>
          </a>
          <a href="#panels" className="ds-nav-item">
            <span className="nav-number">08</span>
            <span>Panels</span>
          </a>
          <a href="#data" className="ds-nav-item">
            <span className="nav-number">09</span>
            <span>Data Display</span>
          </a>
          <a href="#spacing" className="ds-nav-item">
            <span className="nav-number">10</span>
            <span>Spacing</span>
          </a>
          <a href="#export" className="ds-nav-item">
            <span className="nav-number">11</span>
            <span>Export & Sync</span>
          </a>
        </div>

        <div className="vertical-project-label">
          ZINC PROJECT SYSTEM v2.4
        </div>
      </nav>

      {/* Main Content */}
      <main className="ds-content">
        {/* Header */}
        <header className="ds-header">
          <div className="header-title">
            <span className="dna-number">01</span>
            <div className="header-text">
              <h1>AISI Design System</h1>
              <p className="dna-uppercase">Professional Astrology Platform Component Library</p>
            </div>
          </div>
        </header>

        {/* Content Sections */}
        <div className="ds-sections">
          
          {/* Introduction */}
          <section className="ds-section" id="intro">
            <div className="section-intro">
              <h2 className="section-title-large">Design System Overview</h2>
              <p className="intro-text">
                A comprehensive component library and design token system for building professional astrology applications. 
                This system emphasizes clarity, precision, and sophisticated data visualization.
              </p>
            </div>
          </section>

          {/* Color Tokens */}
          <section className="ds-section" id="colors">
            <div className="section-header-block">
              <span className="dna-circle-tag cobalt">02</span>
              <h2 className="section-title-large">Color Palette</h2>
              <p className="section-subtitle">Core brand colors and semantic color tokens</p>
            </div>

            {/* Primary Colors */}
            <div className="component-group">
              <h3 className="group-title">Primary Colors</h3>
              <div className="color-grid">
                <div className="color-card">
                  <div className="color-swatch bg-cobalt"></div>
                  <div className="color-info">
                    <span className="color-name">Cobalt</span>
                    <span className="color-token">--c-cobalt</span>
                    <span className="color-value">#1F5673</span>
                  </div>
                </div>
                <div className="color-card">
                  <div className="color-swatch bg-blush"></div>
                  <div className="color-info">
                    <span className="color-name">Blush</span>
                    <span className="color-token">--c-blush</span>
                    <span className="color-value">#D98E73</span>
                  </div>
                </div>
                <div className="color-card">
                  <div className="color-swatch bg-fg"></div>
                  <div className="color-info">
                    <span className="color-name">Foreground</span>
                    <span className="color-token">--c-fg</span>
                    <span className="color-value">#2A363B</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Neutral Colors */}
            <div className="component-group">
              <h3 className="group-title">Neutral Scale (Zinc)</h3>
              <div className="color-grid">
                <div className="color-card">
                  <div className="color-swatch bg-zinc-light"></div>
                  <div className="color-info">
                    <span className="color-name">Zinc Light</span>
                    <span className="color-token">--c-zinc-light</span>
                    <span className="color-value">#F3F1EA</span>
                  </div>
                </div>
                <div className="color-card">
                  <div className="color-swatch bg-zinc-medium"></div>
                  <div className="color-info">
                    <span className="color-name">Zinc Medium</span>
                    <span className="color-token">--c-zinc-medium</span>
                    <span className="color-value">#BCCACD</span>
                  </div>
                </div>
                <div className="color-card">
                  <div className="color-swatch bg-zinc-dark"></div>
                  <div className="color-info">
                    <span className="color-name">Zinc Dark</span>
                    <span className="color-token">--c-zinc-dark</span>
                    <span className="color-value">#6B7C85</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Functional Colors */}
            <div className="component-group">
              <h3 className="group-title">Functional Colors</h3>
              <div className="color-grid">
                <div className="color-card">
                  <div className="color-swatch" style={{ background: 'var(--c-bg)' }}></div>
                  <div className="color-info">
                    <span className="color-name">Background</span>
                    <span className="color-token">--c-bg</span>
                    <span className="color-value">#FDFCF9</span>
                  </div>
                </div>
                <div className="color-card">
                  <div className="color-swatch" style={{ background: 'var(--c-blush-dim)' }}></div>
                  <div className="color-info">
                    <span className="color-name">Blush Dim</span>
                    <span className="color-token">--c-blush-dim</span>
                    <span className="color-value">#EEF4F4</span>
                  </div>
                </div>
                <div className="color-card">
                  <div className="color-swatch" style={{ background: 'var(--c-node-bg)' }}></div>
                  <div className="color-info">
                    <span className="color-name">Node Background</span>
                    <span className="color-token">--c-node-bg</span>
                    <span className="color-value">#F2F6F7</span>
                  </div>
                </div>
                <div className="color-card">
                  <div className="color-swatch" style={{ background: 'var(--c-border)', border: '1px solid var(--c-zinc-medium)' }}></div>
                  <div className="color-info">
                    <span className="color-name">Border</span>
                    <span className="color-token">--c-border</span>
                    <span className="color-value">#DEDBD0</span>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Typography */}
          <section className="ds-section" id="typography">
            <div className="section-header-block">
              <span className="dna-circle-tag cobalt">03</span>
              <h2 className="section-title-large">Typography</h2>
              <p className="section-subtitle">Type scale and font families</p>
            </div>

            {/* Font Families */}
            <div className="component-group">
              <h3 className="group-title">Font Families</h3>
              <div className="font-family-grid">
                <div className="font-sample">
                  <div className="font-display" style={{ fontFamily: 'var(--f-sans)' }}>
                    Aa
                  </div>
                  <div className="font-info">
                    <span className="font-name">Sans Serif</span>
                    <span className="font-stack">Gill Sans, Helvetica Neue</span>
                    <span className="font-token">--f-sans</span>
                  </div>
                </div>
                <div className="font-sample">
                  <div className="font-display" style={{ fontFamily: 'var(--f-mono)' }}>
                    Aa
                  </div>
                  <div className="font-info">
                    <span className="font-name">Monospace</span>
                    <span className="font-stack">Courier New</span>
                    <span className="font-token">--f-mono</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Type Scale */}
            <div className="component-group">
              <h3 className="group-title">Type Scale</h3>
              <div className="type-scale">
                <div className="type-sample">
                  <div className="type-example dna-number">24px Display</div>
                  <div className="type-meta">
                    <span>DNA Number</span>
                    <span className="type-specs">24px / -0.01em</span>
                  </div>
                </div>
                <div className="type-sample">
                  <div className="type-example stat-value">22px Statistical</div>
                  <div className="type-meta">
                    <span>Stat Value</span>
                    <span className="type-specs">22px / -0.02em</span>
                  </div>
                </div>
                <div className="type-sample">
                  <div className="type-example" style={{ fontSize: '13px' }}>13px Body Text</div>
                  <div className="type-meta">
                    <span>Body</span>
                    <span className="type-specs">13px / 0.04em</span>
                  </div>
                </div>
                <div className="type-sample">
                  <div className="type-example" style={{ fontSize: '12px' }}>12px Secondary</div>
                  <div className="type-meta">
                    <span>Base</span>
                    <span className="type-specs">12px / 0.04em</span>
                  </div>
                </div>
                <div className="type-sample">
                  <div className="type-example dna-uppercase">10px Uppercase Label</div>
                  <div className="type-meta">
                    <span>DNA Uppercase</span>
                    <span className="type-specs">10px / 0.12em</span>
                  </div>
                </div>
                <div className="type-sample">
                  <div className="type-example" style={{ fontSize: '9px' }}>9px Micro</div>
                  <div className="type-meta">
                    <span>Micro</span>
                    <span className="type-specs">9px / 0.05em</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Typography Components */}
            <div className="component-group">
              <h3 className="group-title">Typography Components</h3>
              <div className="component-examples">
                <div className="example-card">
                  <div className="example-preview">
                    <span className="dna-number">05</span>
                  </div>
                  <div className="example-info">
                    <span className="example-name">DNA Number</span>
                    <code className="example-code">.dna-number</code>
                  </div>
                </div>
                <div className="example-card">
                  <div className="example-preview">
                    <span className="dna-uppercase">Analysis Workspace</span>
                  </div>
                  <div className="example-info">
                    <span className="example-name">DNA Uppercase</span>
                    <code className="example-code">.dna-uppercase</code>
                  </div>
                </div>
                <div className="example-card">
                  <div className="example-preview">
                    <span className="section-title">Selection Analysis</span>
                  </div>
                  <div className="example-info">
                    <span className="example-name">Section Title</span>
                    <code className="example-code">.section-title</code>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Buttons */}
          <section className="ds-section" id="buttons">
            <div className="section-header-block">
              <span className="dna-circle-tag cobalt">04</span>
              <h2 className="section-title-large">Buttons</h2>
              <p className="section-subtitle">Action components and interactive elements</p>
            </div>

            <div className="component-group">
              <h3 className="group-title">Button Variants</h3>
              <div className="button-showcase">
                <div className="button-row">
                  <div className="button-example">
                    <button className="btn primary">Primary Button</button>
                    <code>.btn.primary</code>
                  </div>
                  <div className="button-example">
                    <button className="btn">Default Button</button>
                    <code>.btn</code>
                  </div>
                  <div className="button-example">
                    <button className="btn" disabled>Disabled</button>
                    <code>.btn:disabled</code>
                  </div>
                </div>
              </div>
            </div>

            <div className="component-group">
              <h3 className="group-title">Icon Buttons</h3>
              <div className="icon-button-showcase">
                <div className="icon-button-row">
                  <div className="icon-btn">+</div>
                  <div className="icon-btn">-</div>
                  <div className="icon-btn">×</div>
                  <div className="icon-btn">Fit</div>
                </div>
                <code>.icon-btn</code>
              </div>
            </div>

            <div className="component-group">
              <h3 className="group-title">Button Groups</h3>
              <div className="button-showcase">
                <div className="tool-controls">
                  <button className="btn">Auto Layout</button>
                  <button className="btn">Add Node +</button>
                  <button className="btn primary">Run Calculation</button>
                </div>
                <code>.tool-controls</code>
              </div>
            </div>
          </section>

          {/* Badges & Tags */}
          <section className="ds-section" id="badges">
            <div className="section-header-block">
              <span className="dna-circle-tag cobalt">05</span>
              <h2 className="section-title-large">Badges & Tags</h2>
              <p className="section-subtitle">Labels, identifiers, and status indicators</p>
            </div>

            <div className="component-group">
              <h3 className="group-title">Circle Tags</h3>
              <div className="badge-showcase">
                <div className="badge-row">
                  <div className="badge-example">
                    <span className="dna-circle-tag">A</span>
                    <code>.dna-circle-tag</code>
                  </div>
                  <div className="badge-example">
                    <span className="dna-circle-tag cobalt">01</span>
                    <code>.cobalt</code>
                  </div>
                  <div className="badge-example">
                    <span className="dna-circle-tag blush">02</span>
                    <code>.blush</code>
                  </div>
                </div>
              </div>
            </div>

            <div className="component-group">
              <h3 className="group-title">Node Type Badges</h3>
              <div className="badge-showcase">
                <div className="badge-row">
                  <span className="node-type-badge">SOURCE</span>
                  <span className="node-type-badge" style={{ background: 'var(--c-blush-dim)', color: 'var(--c-cobalt)', borderColor: 'transparent' }}>NATAL</span>
                  <span className="node-type-badge" style={{ background: '#FDE8E4', color: 'var(--c-blush)', borderColor: 'transparent' }}>TIME</span>
                  <span className="node-type-badge">RESULT</span>
                </div>
                <code>.node-type-badge</code>
              </div>
            </div>

            <div className="component-group">
              <h3 className="group-title">Node Index</h3>
              <div className="badge-showcase">
                <div className="badge-row">
                  <span className="node-index">01</span>
                  <span className="node-index" style={{ background: 'var(--c-blush)' }}>02</span>
                  <span className="node-index" style={{ background: 'var(--c-zinc-dark)' }}>03</span>
                </div>
                <code>.node-index</code>
              </div>
            </div>
          </section>

          {/* Navigation */}
          <section className="ds-section" id="navigation">
            <div className="section-header-block">
              <span className="dna-circle-tag cobalt">06</span>
              <h2 className="section-title-large">Navigation</h2>
              <p className="section-subtitle">Menu items and navigation patterns</p>
            </div>

            <div className="component-group">
              <h3 className="group-title">Navigation Items</h3>
              <div className="nav-showcase">
                <div className="nav-example-container">
                  <a href="#" className="nav-item">
                    <span className="nav-number">00</span>
                    <span>Dashboard</span>
                  </a>
                  <a href="#" className="nav-item active">
                    <span className="nav-number">01</span>
                    <span>Nodes</span>
                  </a>
                  <a href="#" className="nav-item">
                    <span className="nav-number">02</span>
                    <span>Reports</span>
                  </a>
                </div>
                <code>.nav-item / .nav-item.active</code>
              </div>
            </div>
          </section>

          {/* Node Cards */}
          <section className="ds-section" id="nodes">
            <div className="section-header-block">
              <span className="dna-circle-tag cobalt">07</span>
              <h2 className="section-title-large">Node Cards</h2>
              <p className="section-subtitle">Data visualization cards and containers</p>
            </div>

            <div className="component-group">
              <h3 className="group-title">Node Variants</h3>
              <div className="node-showcase">
                <div className="node-example-wrapper">
                  {/* Default Node */}
                  <div className="node" style={{ position: 'relative' }}>
                    <span className="node-index">01</span>
                    <div className="node-header">
                      <span className="node-title">Natal Profile</span>
                      <span className="node-type-badge">SOURCE</span>
                    </div>
                    <div className="node-content">
                      <div className="data-row">
                        <span>Subject</span>
                        <span className="data-value">J. Doe</span>
                      </div>
                      <div className="data-row">
                        <span>Sun</span>
                        <span className="data-value">24° Leo</span>
                      </div>
                      <div className="data-row">
                        <span>Moon</span>
                        <span className="data-value">12° Tau</span>
                      </div>
                    </div>
                  </div>
                  <code>.node</code>
                </div>

                <div className="node-example-wrapper">
                  {/* Selected Node */}
                  <div className="node selected" style={{ position: 'relative' }}>
                    <span className="node-index">02</span>
                    <div className="node-header">
                      <span className="node-title">Current Transit</span>
                      <span className="node-type-badge" style={{ background: '#FDE8E4', color: 'var(--c-blush)', borderColor: 'transparent' }}>TIME</span>
                    </div>
                    <div className="node-content">
                      <div className="data-row">
                        <span>Date</span>
                        <span className="data-value">Oct 24, 2023</span>
                      </div>
                      <div className="data-row">
                        <span>Active</span>
                        <span className="data-value text-cobalt">Saturn Square</span>
                      </div>
                    </div>
                  </div>
                  <code>.node.selected</code>
                </div>

                <div className="node-example-wrapper">
                  {/* Natal Node */}
                  <div className="node natal" style={{ position: 'relative' }}>
                    <span className="node-index" style={{ background: 'var(--c-blush)' }}>03</span>
                    <div className="node-header">
                      <span className="node-title" style={{ color: 'var(--c-blush)' }}>Person B Profile</span>
                      <span className="node-type-badge" style={{ background: '#FDE8E4', color: 'var(--c-blush)', borderColor: 'transparent' }}>NATAL</span>
                    </div>
                    <div className="node-content">
                      <div className="data-row">
                        <span>Subject</span>
                        <span className="data-value">A. Smith</span>
                      </div>
                      <div className="data-row">
                        <span>Sun</span>
                        <span className="data-value">08° Aqu</span>
                      </div>
                    </div>
                  </div>
                  <code>.node.natal</code>
                </div>
              </div>
            </div>
          </section>

          {/* Panels */}
          <section className="ds-section" id="panels">
            <div className="section-header-block">
              <span className="dna-circle-tag cobalt">08</span>
              <h2 className="section-title-large">Panels</h2>
              <p className="section-subtitle">Inspector panels and content sections</p>
            </div>

            <div className="component-group">
              <h3 className="group-title">Panel Sections</h3>
              <div className="panel-showcase">
                <div className="panel-section">
                  <div className="section-header">
                    <span className="section-title">
                      <span className="dna-circle-tag cobalt">01</span>
                      Active Aspects
                    </span>
                  </div>
                  <div className="list-item">
                    <span style={{ fontWeight: 500 }}>Sun Square Saturn</span>
                    <span className="text-cobalt" style={{ fontFamily: 'var(--f-mono)' }}>0.2°</span>
                  </div>
                  <div className="list-item">
                    <span>Venus Trine Mars</span>
                    <span style={{ fontFamily: 'var(--f-mono)', color: 'var(--c-zinc-dark)' }}>1.4°</span>
                  </div>
                </div>
                <code>.panel-section</code>
              </div>

              <div className="panel-showcase">
                <div className="panel-section highlight">
                  <div className="section-header">
                    <span className="section-title">
                      <span className="dna-circle-tag cobalt">02</span>
                      Highlighted Section
                    </span>
                  </div>
                  <div className="stat-grid">
                    <div className="stat-item">
                      <span className="stat-label">Dominant</span>
                      <span className="stat-value">Fire</span>
                    </div>
                    <div className="stat-item">
                      <span className="stat-label">Vitality</span>
                      <span className="stat-value">High</span>
                    </div>
                  </div>
                </div>
                <code>.panel-section.highlight</code>
              </div>
            </div>
          </section>

          {/* Data Display */}
          <section className="ds-section" id="data">
            <div className="section-header-block">
              <span className="dna-circle-tag cobalt">09</span>
              <h2 className="section-title-large">Data Display</h2>
              <p className="section-subtitle">Data presentation components</p>
            </div>

            <div className="component-group">
              <h3 className="group-title">Data Rows</h3>
              <div className="data-showcase">
                <div className="showcase-container">
                  <div className="data-row">
                    <span>Subject</span>
                    <span className="data-value">J. Doe</span>
                  </div>
                  <div className="data-row">
                    <span>Active</span>
                    <span className="data-value text-cobalt">Saturn Square</span>
                  </div>
                  <div className="data-row">
                    <span>Risk</span>
                    <span className="data-value text-blush">High Volatility</span>
                  </div>
                </div>
                <code>.data-row + .data-value</code>
              </div>
            </div>

            <div className="component-group">
              <h3 className="group-title">Stat Grid</h3>
              <div className="data-showcase">
                <div className="showcase-container">
                  <div className="stat-grid">
                    <div className="stat-item">
                      <span className="stat-label">Align</span>
                      <span className="stat-value text-cobalt">84%</span>
                    </div>
                    <div className="stat-item">
                      <span className="stat-label">Friction</span>
                      <span className="stat-value">Low</span>
                    </div>
                    <div className="stat-item">
                      <span className="stat-label">Dominant</span>
                      <span className="stat-value">Fire</span>
                    </div>
                    <div className="stat-item">
                      <span className="stat-label">Vitality</span>
                      <span className="stat-value">High</span>
                    </div>
                  </div>
                </div>
                <code>.stat-grid + .stat-item</code>
              </div>
            </div>

            <div className="component-group">
              <h3 className="group-title">Progress Bars</h3>
              <div className="data-showcase">
                <div className="showcase-container">
                  <div className="stat-item" style={{ marginBottom: '12px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span className="stat-label">10th House (Career)</span>
                      <span className="stat-label">92%</span>
                    </div>
                    <div className="progress-bar">
                      <div className="progress-fill" style={{ width: '92%' }}></div>
                    </div>
                  </div>
                  <div className="stat-item">
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span className="stat-label">7th House (Relationships)</span>
                      <span className="stat-label">45%</span>
                    </div>
                    <div className="progress-bar">
                      <div className="progress-fill" style={{ width: '45%', background: 'var(--c-zinc-medium)' }}></div>
                    </div>
                  </div>
                </div>
                <code>.progress-bar + .progress-fill</code>
              </div>
            </div>

            <div className="component-group">
              <h3 className="group-title">List Items</h3>
              <div className="data-showcase">
                <div className="showcase-container">
                  <div className="list-item">
                    <span style={{ fontWeight: 500 }}>Sun Square Saturn</span>
                    <span className="text-cobalt" style={{ fontFamily: 'var(--f-mono)' }}>0.2°</span>
                  </div>
                  <div className="list-item">
                    <span>Venus Trine Mars</span>
                    <span style={{ fontFamily: 'var(--f-mono)', color: 'var(--c-zinc-dark)' }}>1.4°</span>
                  </div>
                  <div className="list-item">
                    <span>Moon Opp Pluto</span>
                    <span style={{ fontFamily: 'var(--f-mono)', color: 'var(--c-zinc-dark)' }}>2.1°</span>
                  </div>
                </div>
                <code>.list-item</code>
              </div>
            </div>
          </section>

          {/* Spacing */}
          <section className="ds-section" id="spacing">
            <div className="section-header-block">
              <span className="dna-circle-tag cobalt">10</span>
              <h2 className="section-title-large">Spacing System</h2>
              <p className="section-subtitle">Consistent spacing scale based on 4px grid</p>
            </div>

            <div className="component-group">
              <h3 className="group-title">Spacing Scale</h3>
              <div className="spacing-showcase">
                <div className="spacing-item">
                  <div className="spacing-visual" style={{ width: '4px' }}></div>
                  <div className="spacing-info">
                    <span className="spacing-size">4px</span>
                    <span className="spacing-token">--space-xs</span>
                  </div>
                </div>
                <div className="spacing-item">
                  <div className="spacing-visual" style={{ width: '8px' }}></div>
                  <div className="spacing-info">
                    <span className="spacing-size">8px</span>
                    <span className="spacing-token">--space-sm</span>
                  </div>
                </div>
                <div className="spacing-item">
                  <div className="spacing-visual" style={{ width: '12px' }}></div>
                  <div className="spacing-info">
                    <span className="spacing-size">12px</span>
                    <span className="spacing-token">--space-md</span>
                  </div>
                </div>
                <div className="spacing-item">
                  <div className="spacing-visual" style={{ width: '16px' }}></div>
                  <div className="spacing-info">
                    <span className="spacing-size">16px</span>
                    <span className="spacing-token">--space-lg</span>
                  </div>
                </div>
                <div className="spacing-item">
                  <div className="spacing-visual" style={{ width: '24px' }}></div>
                  <div className="spacing-info">
                    <span className="spacing-size">24px</span>
                    <span className="spacing-token">--space-xl</span>
                  </div>
                </div>
                <div className="spacing-item">
                  <div className="spacing-visual" style={{ width: '32px' }}></div>
                  <div className="spacing-info">
                    <span className="spacing-size">32px</span>
                    <span className="spacing-token">--space-2xl</span>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Export Section */}
          <section className="ds-section" id="export">
            <div className="section-header-block">
              <span className="dna-circle-tag cobalt">11</span>
              <h2 className="section-title-large">Export & Sync</h2>
              <p className="section-subtitle">Bridge the gap between code and Figma</p>
            </div>

            <div className="component-group">
              <h3 className="group-title">Figma Token JSON</h3>
              <p className="description-text mb-4">
                Copy these tokens to import into <strong>Tokens Studio</strong> or manually create <strong>Figma Local Variables</strong>.
              </p>
              <div className="export-container">
                <pre className="token-json-block">
{`{
  "colors": {
    "cobalt": { "value": "#1F5673", "type": "color" },
    "blush": { "value": "#D98E73", "type": "color" },
    "zinc": {
      "light": { "value": "#F3F1EA", "type": "color" },
      "medium": { "value": "#BCCACD", "type": "color" },
      "dark": { "value": "#6B7C85", "type": "color" }
    },
    "bg": { "value": "#FDFCF9", "type": "color" },
    "fg": { "value": "#2A363B", "type": "color" }
  },
  "typography": {
    "fontFamilies": {
      "sans": { "value": "Gill Sans", "type": "fontFamilies" },
      "mono": { "value": "Courier New", "type": "fontFamilies" }
    }
  }
}`}
                </pre>
                <button 
                  className="btn primary mt-4"
                  onClick={async () => {
                    const text = document.querySelector('.token-json-block')?.textContent || "";
                    try {
                      await navigator.clipboard.writeText(text);
                      alert('Tokens copied to clipboard!');
                    } catch (err) {
                      const element = document.querySelector('.token-json-block');
                      if (element) {
                        const range = document.createRange();
                        range.selectNodeContents(element);
                        const selection = window.getSelection();
                        if (selection) {
                          selection.removeAllRanges();
                          selection.addRange(range);
                          alert('Copy blocked by browser permissions. The text is now selected—please press Ctrl+C (Cmd+C) to copy manually.');
                        }
                      }
                    }
                  }}
                >
                  Copy Tokens for Figma
                </button>
              </div>
            </div>

            <div className="component-group">
              <h3 className="group-title">Syncing Components</h3>
              <div className="sync-guide">
                <div className="guide-step">
                  <span className="step-num">01</span>
                  <div className="step-content">
                    <strong>Install html.to.design</strong>
                    <p>Install the plugin from the Figma Community to convert live sites to Figma layers.</p>
                  </div>
                </div>
                <div className="guide-step">
                  <span className="step-num">02</span>
                  <div className="step-content">
                    <strong>Copy Preview URL</strong>
                    <p>Copy the URL of this running application from your browser address bar.</p>
                  </div>
                </div>
                <div className="guide-step">
                  <span className="step-num">03</span>
                  <div className="step-content">
                    <strong>Import to Figma</strong>
                    <p>Paste the URL into the plugin, select your viewport, and click "Import".</p>
                  </div>
                </div>
              </div>
            </div>
          </section>

        </div>
      </main>

      {/* Footer */}
      <footer className="ds-footer">
        <div className="footer-item">
          <span>Version:</span>
          <span className="footer-value">2.4</span>
        </div>
        <div className="footer-item">
          <span>System:</span>
          <span className="footer-value">ZINC PROJECT</span>
        </div>
        <div className="footer-item" style={{ marginLeft: 'auto' }}>
          <span>Components:</span>
          <span className="footer-value">47</span>
        </div>
      </footer>
    </div>
  );
}
